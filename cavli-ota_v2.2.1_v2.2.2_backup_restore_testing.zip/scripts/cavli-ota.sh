#!/bin/bash

# Get the directory where this script is located, even when sourced
CAVLI_OTA_DIR="$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")"
APPS_DIR="${CAVLI_OTA_DIR}/../apps"

# File paths
KERNEL_MTD_NAME="boot"
KERNEL_IMG_FILE="${CAVLI_OTA_DIR}/../images/mdm9607-boot.img"
IMAGE_CHECKSUMS_FILE="${CAVLI_OTA_DIR}/../images/image_checksums.sha256"
ROOTFS_PACKAGE="${CAVLI_OTA_DIR}/../delta/rootfs.tar.gz"
ROOTFS_DELETE_LIST="${CAVLI_OTA_DIR}/../delta/deleted_files.txt"
FIRMWARE_PACKAGE="${CAVLI_OTA_DIR}/../delta/firmware.tar.gz"
DELTA_CHECKSUMS_FILE="${CAVLI_OTA_DIR}/../delta/delta_checksums.sha256"
OTA_INFO_FILE="/data/cavli-ota-info.log"
OTA_LOG_FILE="/data/cavli-ota-runtime.log"
OTA_STATUS_FILE="/data/cavli-ota-status.txt"

# Source the logging script
source "${CAVLI_OTA_DIR}/utils/cavli_log.sh"
# Set custom log tag for this script
set_log_tag "[CAVLI-OTA]"

# Source update_partition script
source "${CAVLI_OTA_DIR}/utils/update_partition.sh"
# Source checksum verification script
source "${CAVLI_OTA_DIR}/utils/checksum.sh"
# Source cfdps script
source "${CAVLI_OTA_DIR}/cfdps/cfdps.sh"

# Function to safely run commands with error handling
safe_run() {
    "$@"
    if [ $? -ne 0 ]; then
        log_error "Command '$*' failed. Rebooting..."
        {
            echo "========== OTA RECOVERY INFO =========="
            echo "Date       : $(date)"
            echo "Kernel     : $(basename "$KERNEL_IMG_FILE")"
            echo "Rootfs     : $(basename "$ROOTFS_PACKAGE")"
            echo "Firmware   : $(basename "$FIRMWARE_PACKAGE")"
            echo "Status     : FAILED"
            echo "Failure    : Command '$*' failed"
            echo "========================================"
        } >> "$OTA_INFO_FILE"
        
        chmod +x /usr/bin/atcmd
        sync
        # Unlock recovery mode before rebooting
        ${APPS_DIR}/recovery --finish
        sync
        log_info "Recovery mode unlocked successfully"
        log_at "+OTA: RECOVERY_UNLOCKED"
        reboot
        exit 1
    fi
}

# OTA status management - simple text file based approach
get_ota_status() {
    local key="$1"
    local default_value="$2"
    
    # If status file doesn't exist, return default value
    if [ ! -f "$OTA_STATUS_FILE" ]; then
        echo "$default_value"
        return
    fi
    
    # Extract value from file using grep
    local value=$(grep "^${key}=" "$OTA_STATUS_FILE" | cut -d'=' -f2)
    
    # Return default if not found
    if [ -z "$value" ]; then
        echo "$default_value"
    else
        echo "$value"
    fi
}

# Update a specific status
update_ota_status() {
    local key="$1"
    local value="$2"
    
    # Create directory if needed
    mkdir -p "$(dirname "$OTA_STATUS_FILE")" 2>/dev/null
    
    # Create file if it doesn't exist
    if [ ! -f "$OTA_STATUS_FILE" ]; then
        reset_ota_status
    fi
    
    # Update existing key or add new one
    if grep -q "^${key}=" "$OTA_STATUS_FILE"; then
        # Replace existing key
        sed -i "s/^${key}=.*/${key}=${value}/" "$OTA_STATUS_FILE"
    else
        # Add new key
        echo "${key}=${value}" >> "$OTA_STATUS_FILE"
    fi
    
    # Ensure changes are written to disk
    sync
}

# Log OTA information
log_ota_info() {
    local status="$1"
    
    {
        echo "========== OTA RECOVERY INFO =========="
        echo "Date       : $(date)"
        echo "Kernel     : $(basename "$KERNEL_IMG_FILE")"
        echo "Rootfs     : $(basename "$ROOTFS_PACKAGE")"
        echo "Firmware   : $(basename "$FIRMWARE_PACKAGE")"
        echo "Status     : $status"
        
        if [ "$status" = "SUCCESS" ]; then
            echo "Message    : OTA update completed successfully"
        else
            echo "Message    : $2"
        fi
        
        # Add checksums of important files
        echo "========== File Checksums =========="
        if [ -f "$KERNEL_IMG_FILE" ]; then
            sha256sum "$KERNEL_IMG_FILE"
        fi
        if [ -f "$ROOTFS_PACKAGE" ]; then
            sha256sum "$ROOTFS_PACKAGE"
        fi
        if [ -f "$FIRMWARE_PACKAGE" ]; then
            sha256sum "$FIRMWARE_PACKAGE"
        fi
        echo "========================================"
    } >> "$OTA_INFO_FILE"
}

# Update kernel using update_partition
update_kernel() {
    # Check if kernel is already flashed in this update cycle
    local kernel_flashed=$(get_ota_status "kernel_flashed" "0")
    if [ "$kernel_flashed" = "1" ]; then
        log_info "Kernel already flashed in this update cycle. Skipping."
        return 0
    fi

    log_info "Updating kernel partition..."
    
    # Check if kernel image exists
    if [ ! -f "$KERNEL_IMG_FILE" ]; then
        log_error "Kernel image not found: $KERNEL_IMG_FILE"
        log_ota_info "FAILED" "Kernel image not found"
        return 1
    fi
    
    # Send AT command to indicate kernel update in progress
    log_at "+OTA: KERNEL_UPDATE_STARTED"
    
    # Update kernel partition using flag-style arguments
    update_partition "$KERNEL_MTD_NAME" "$KERNEL_IMG_FILE" 131072 "$IMAGE_CHECKSUMS_FILE" 0

    local result=$?
    
    if [ $result -eq 0 ]; then
        log_info "Kernel update completed successfully"
        log_at "+OTA: KERNEL_UPDATE_SUCCESS"
        # Mark kernel as flashed
        update_ota_status "kernel_flashed" "1"
        # Remove kernel image file
        rm -f "$KERNEL_IMG_FILE"
        # Sync changes to disk
        sync
    else
        log_error "Kernel update failed with error code $result"
        log_at "+OTA: KERNEL_UPDATE_FAILED"
        return $result
    fi
    
    return 0
}

# Update rootfs with delta package
update_rootfs() {
    # Check if rootfs is already flashed in this update cycle
    local rootfs_flashed=$(get_ota_status "rootfs_flashed" "0")
    if [ "$rootfs_flashed" = "1" ]; then
        log_info "Rootfs already flashed in this update cycle. Skipping."
        return 0
    fi

    log_info "Updating rootfs with delta package..."

    # Check if rootfs package exists
    if [ ! -f "$ROOTFS_PACKAGE" ]; then
        log_error "Rootfs package not found: $ROOTFS_PACKAGE"
        log_ota_info "FAILED" "Rootfs package not found"
        return 1
    fi
    
    # Verify rootfs package checksum before proceeding
    log_info "Verifying checksum for rootfs package..."
    if [ -f "$DELTA_CHECKSUMS_FILE" ]; then
        if ! verify_checksum "$ROOTFS_PACKAGE" "$DELTA_CHECKSUMS_FILE"; then
            log_error "Rootfs package checksum verification failed. Aborting update."
            log_ota_info "FAILED" "Rootfs package checksum verification failed"
            log_at "+OTA: ROOTFS_CHECKSUM_FAILED"
            return 1
        fi
        if ! verify_checksum "$ROOTFS_DELETE_LIST" "$DELTA_CHECKSUMS_FILE"; then
            log_error "Rootfs delete list file checksum verification failed. Aborting update."
            log_ota_info "FAILED" "Rootfs package checksum verification failed"
            log_at "+OTA: ROOTFS_CHECKSUM_FAILED"
            return 1
        fi
        log_info "Rootfs package checksum verification passed!"
    else
        log_warn "No checksum file found at $DELTA_CHECKSUMS_FILE, continuing without verification"
    fi

    # Send AT command to indicate rootfs update in progress
    log_at "+OTA: ROOTFS_UPDATE_STARTED"
    
    # Remount root filesystem as read-write
    log_info "Remounting root filesystem as read-write"
    mount -o remount,rw /
    if [ $? -ne 0 ]; then
        log_error "Failed to remount root filesystem as read-write"
        log_ota_info "FAILED" "Could not remount rootfs as rw"
        return 1
    fi
    
    # Process file deletions if delete_files.txt exists
    if [ -f "$ROOTFS_DELETE_LIST" ]; then
        log_info "Processing file deletions"
        local deleted_count=0
        
        # Read file line by line and delete each file
        while IFS= read -r file_to_delete || [ -n "$file_to_delete" ]; do
            # Skip empty lines and comments
            [[ -z "$file_to_delete" || "$file_to_delete" == \#* ]] && continue
            
            # Make path absolute if it's not already
            [[ "$file_to_delete" != /* ]] && file_to_delete="/$file_to_delete"
            
            # First check if it's a symlink (before checking if it exists)
            if [ -L "$file_to_delete" ]; then
                log_info "Removing symlink: $file_to_delete"
                rm -f "$file_to_delete"
                ((deleted_count++))
            # Then check if it's a directory
            elif [ -d "$file_to_delete" ]; then
                log_info "Removing directory: $file_to_delete"
                rm -rf "$file_to_delete"
                ((deleted_count++))
            # Finally check if it's a regular file
            elif [ -e "$file_to_delete" ]; then
                log_info "Removing file: $file_to_delete"
                rm -f "$file_to_delete"
                ((deleted_count++))
            else
                log_debug "File not found, skipping: $file_to_delete"
            fi
        done < "$ROOTFS_DELETE_LIST"
        
        log_info "Deleted $deleted_count files/directories/symlinks"
        sync  # Sync after deletion operations
    else
        log_info "No deletion list found, skipping file deletions"
    fi
    
    # Extract rootfs package directly to root
    log_info "Extracting rootfs package directly to /"
    tar -xzvf "$ROOTFS_PACKAGE" -C /
    local result=$?
    
    if [ $result -eq 0 ]; then
        log_info "Rootfs update completed successfully"
        log_at "+OTA: ROOTFS_UPDATE_SUCCESS"
        # Mark rootfs as flashed
        update_ota_status "rootfs_flashed" "1"
        # Remove rootfs package
        rm -f "$ROOTFS_PACKAGE"
        # Sync changes to disk
        sync
    else
        log_error "Rootfs update failed with error code $result"
        log_at "+OTA: ROOTFS_UPDATE_FAILED"
        return $result
    fi
    
    return 0
}

# Add this function after the reset_ota_status() function
ensure_firmware_writable() {
    log_info "Ensuring firmware partition (on UBI1) is writable..."

    # Find and mount the firmware partition
    sh "${CAVLI_OTA_DIR}/utils/find_partitions.sh"

    # Remount read/write
    mount -o remount,rw /firmware

    if mount | grep -q "/firmware"; then
        log_info "Firmware partition is now writable"
    else
        log_error "Failed to remount firmware partition as writable"
        return 1
    fi

    # Add this to test basic write capability
    echo "test" > /firmware/image/test_write
    if [ $? -eq 0 ]; then
        log_info "Basic write test successful"
        rm -f /firmware/image/test_write
    else
        log_error "Basic write test failed - filesystem may be read-only or full"
        return 1
    fi

    return 0
}

update_firmware() {
    # Check if firmware is already flashed in this update cycle
    local firmware_flashed=$(get_ota_status "firmware_flashed" "0")
    if [ "$firmware_flashed" = "1" ]; then
        log_info "Firmware already flashed in this update cycle. Skipping."
        return 0
    fi

    log_info "Updating firmware..."
    
    # Check if firmware package exists
    if [ ! -f "$FIRMWARE_PACKAGE" ]; then
        log_info "Firmware package not found: $FIRMWARE_PACKAGE. Skipping firmware update."
        return 0
    fi
    
    # Verify firmware package checksum before proceeding
    log_info "Verifying checksum for firmware package..."
    if [ -f "$DELTA_CHECKSUMS_FILE" ]; then
        if ! verify_checksum "$FIRMWARE_PACKAGE" "$DELTA_CHECKSUMS_FILE"; then
            log_error "Firmware package checksum verification failed. Aborting update."
            log_ota_info "FAILED" "Firmware package checksum verification failed"
            log_at "+OTA: FIRMWARE_CHECKSUM_FAILED"
            return 1
        fi
        log_info "Firmware package checksum verification passed!"
    else
        log_warn "No checksum file found at $DELTA_CHECKSUMS_FILE, continuing without verification"
    fi

    # Send AT command to indicate firmware update in progress
    log_at "+OTA: FIRMWARE_UPDATE_STARTED"

    log_info "Ensuring firmware partition is properly mounted and writable"
    if ! ensure_firmware_writable; then
        log_error "Failed to make firmware partition writable. Aborting."
        log_at "+OTA: FIRMWARE_MOUNT_FAILED"
        return 1
    fi

    # Extract firmware tar.gz to a temporary location
    log_info "Extracting firmware package..."
    # local TEMP_DIR="${CAVLI_OTA_DIR}/../tmp/firmware"
    local TEMP_DIR="/tmp/firmware"
    mkdir -p "$TEMP_DIR"
    tar -xzvf "$FIRMWARE_PACKAGE" -C "$TEMP_DIR"
    local result=$?
    
    if [ $result -ne 0 ]; then
        log_error "Failed to extract firmware package with error code $result"
        log_at "+OTA: FIRMWARE_UPDATE_FAILED"
        rm -rf "$TEMP_DIR"
        return $result
    fi

    # Use tmp folder (RAM) to hold bspatch output
    local BSPATCH_OUTDIR="/tmp/firmware/image"
    local CFDPS_TAG_PREFIX="fw_update_"
    # Use cfdps
    cfdps_init

    # Try to restore anyfile in cfdps with prefix
    cfdps_restore_all_with_prefix "$CFDPS_TAG_PREFIX" "/firmware/image"

    # Clean up
    cfdps_delete_all_file_parts

    # Apply the patches if there are any
    if [ -d "$TEMP_DIR" ]; then
        # Check if bspatch is available
        if [ ! -x "${APPS_DIR}/bspatch" ]; then
            log_error "bspatch tool not found in ${APPS_DIR}"
            log_at "+OTA: FIRMWARE_UPDATE_FAILED"
            rm -rf "$TEMP_DIR"
            return 1
        fi
        
        # Create output directory for patched files
        mkdir -p "$BSPATCH_OUTDIR"
        
        # Process all patch files
        log_info "Applying firmware patches..."
        local patch_count=0
        for patch_file in "$TEMP_DIR"/patches/*.patch; do
            if [ -f "$patch_file" ]; then
                local filename=$(basename -- "$patch_file")
                local original_file="/firmware/image/$(basename ${filename%.patch})"
                local output_file="$BSPATCH_OUTDIR/$(basename ${filename%.patch})"
                local md5_file="$TEMP_DIR/patches/${filename%.patch}.txt"
                local md5_expected=$(cat "$md5_file")
                
                # Check if original file exists
                if [ ! -f "$original_file" ]; then
                    log_warn "Original file for $filename not found. Skipping..."
                    continue
                fi

                # Apply patch
                log_info "Applying patch for $filename..."
                ${APPS_DIR}/bspatch "$original_file" "$output_file" "$patch_file"
                if [ $? -ne 0 ]; then
                    log_warn "Failed to apply patch for $filename"
                    continue
                fi

                # Compute MD5 hash of the patched file
                if [ -f "$md5_file" ]; then
                    local md5_actual=$(md5sum "$output_file" | awk '{print $1}')

                    # Compare MD5 hashes
                    if [ "$md5_actual" != "$md5_expected" ]; then
                        log_warn "MD5 hash mismatch for $filename. Skipping..."
                        continue
                    fi
                else
                    log_warn "MD5 file not found for $filename. Skipping..."
                    continue
                fi

                # Move bspatch out to cfdps (backup file for recovery support if power corrupt when copying to original)
                local tag="${CFDPS_TAG_PREFIX}$(date +%s)"
                cfdps_save_file "$output_file" "$tag"
                # We try to copy the patched file to the original location
                cp -f "$output_file" "$original_file" && sync
                # If without corrupted, we will remove backup file in cfdps
                cfdps_clear_file_parts "$tag"
                # Clean up the firmware copy starting flag file
                rm -f "$output_file"
            fi
        done

        # Do checksum for all firmware files
        local verify_status=0
        for firmware_file in /firmware/image/*; do
            if [ -f "$firmware_file" ]; then
                local md5_actual=$(md5sum "$firmware_file" | awk '{print $1}')
                local md5_expected=$(cat "$TEMP_DIR/patches/$(basename "$firmware_file").txt")
                if [ "$md5_actual" != "$md5_expected" ]; then
                    log_warn "MD5 hash mismatch for $firmware_file. Skipping..."
                    verify_status=1
                fi
            fi
        done
        if [ $verify_status -eq 0 ]; then
            log_info "All firmware files verified successfully."
        else
            log_error "Some firmware files failed verification. Please check the logs."
            log_at "+OTA: FIRMWARE_VERIFICATION_FAILED"
            rm -rf "$TEMP_DIR"
            return 1
        fi
    fi
    
    # cfdps deinit
    cfdps_deinit
    # Remove temporary files
    rm -rf "$TEMP_DIR"
    rm -f "$BSPATCH_OUTDIR/*"
    log_info "Firmware update completed successfully"
    log_at "+OTA: FIRMWARE_UPDATE_SUCCESS"
    # Mark firmware as flashed
    update_ota_status "firmware_flashed" "1"
    # Remove firmware package
    rm -f "$FIRMWARE_PACKAGE"
    sync
    
    return 0
}

# Reset OTA status to default values
reset_ota_status() {
    # Create directory if needed
    mkdir -p "$(dirname "$OTA_STATUS_FILE")" 2>/dev/null
    
    # Write default values
    {
        echo "status=started"
        echo "start_time=$(date +"%Y-%m-%d_%H-%M-%S")"
        echo "kernel_flashed=0"
        echo "rootfs_flashed=0"
        echo "firmware_flashed=0"
    } > "$OTA_STATUS_FILE"
    
    # Ensure changes are written to disk
    sync
}

main() {
    log_info "Starting Cavli OTA update process"
    
    # Create directory for log files if it doesn't exist
    mkdir -p "$(dirname "$OTA_INFO_FILE")" 2>/dev/null
    mkdir -p "$(dirname "$OTA_LOG_FILE")" 2>/dev/null
    
    # Check if we're resuming an existing update
    if [ -f "$OTA_STATUS_FILE" ]; then
        local kernel_flashed=$(get_ota_status "kernel_flashed" "0")
        local rootfs_flashed=$(get_ota_status "rootfs_flashed" "0")
        local firmware_flashed=$(get_ota_status "firmware_flashed" "0")
        
        if [ "$kernel_flashed" = "1" ] || [ "$rootfs_flashed" = "1" ] || [ "$firmware_flashed" = "1" ]; then
            log_info "Resuming interrupted OTA update"
            log_at "+OTA: RESUMING"
        else
            log_info "Starting new OTA update"
            reset_ota_status
            log_at "+OTA: STARTED"
        fi
    else
        log_info "Starting new OTA update"
        reset_ota_status
        log_at "+OTA: STARTED"
    fi

    # Remount root filesystem as read-write
    log_info "Remounting root filesystem as read-write"
    mount -o remount,rw /

    # Prepare /res directory for recovery app
    mkdir -p /res
    sh "${CAVLI_OTA_DIR}/utils/find_recovery_partitions.sh"
    
    # Lock recovery mode
    log_info "Locking recovery mode..."
    ${APPS_DIR}/recovery --recovery
    if [ $? -ne 0 ]; then
        log_error "Failed to lock recovery mode. Aborting OTA update."
        log_ota_info "FAILED" "Could not lock recovery mode"
        log_at "+OTA: FAILED_TO_LOCK_RECOVERY"
        reboot -f
        exit 1
    fi
    # Disable AT command
    chmod -x /usr/bin/atcmd
    sync
    log_info "Recovery mode locked successfully"
    log_at "+OTA: RECOVERY_LOCKED"

    # Update kernel
    log_info "Starting kernel update"
    safe_run update_kernel
    
    # Update rootfs
    log_info "Starting rootfs update"
    safe_run update_rootfs

    # Update firmware
    log_info "Starting firmware update"
    safe_run update_firmware
    
    # Unlock recovery mode
    log_info "Unlocking recovery mode..."
    # Check if both steps completed
    local kernel_flashed=$(get_ota_status "kernel_flashed" "0")
    local rootfs_flashed=$(get_ota_status "rootfs_flashed" "0")
    local firmware_flashed=$(get_ota_status "firmware_flashed" "0")
    
    # Check if all required components were updated
    if [ "$kernel_flashed" = "1" ] && [ "$rootfs_flashed" = "1" ] && [ "$firmware_flashed" = "1" ]; then
        log_info "All update steps completed successfully"
        update_ota_status "completed_time" "$(date +"%Y-%m-%d_%H-%M-%S")"
    fi
    
    # Update completion status
    update_ota_status "status" "completed"
    
    # Enable AT command back
    chmod +x /usr/bin/atcmd
    sync
    ${APPS_DIR}/recovery --finish
    if [ $? -ne 0 ]; then
        log_error "Failed to unlock recovery mode."
        log_ota_info "WARNING" "OTA completed but failed to unlock recovery mode"
        log_at "+OTA: FAILED_TO_UNLOCK_RECOVERY"
    else
        log_info "Recovery mode unlocked successfully"
        log_at "+OTA: RECOVERY_UNLOCKED"
    fi
    
    # Log success information
    log_ota_info "SUCCESS"
    log_info "OTA update completed successfully"
    log_at "+OTA: COMPLETED_SUCCESSFULLY"
    
    # Remove the auto start recovery script
    if [ -f "/etc/init.d/cavli_recovery" ]; then
        rm -f /etc/init.d/cavli_recovery
        log_info "Removed auto start recovery script"
    else
        log_info "No auto start recovery script to remove"
    fi

    # Sync and reboot
    sync
    log_info "Rebooting system..."
    log_at "+OTA: REBOOTING"
    reboot
}

# Execute main function
main
