#!/bin/bash

# Get the directory where this script is located, even when sourced
CAVLI_RECOVERY_DIR="$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")"

# Recovery partition details
MTD_NAME="recovery"
IMAGE_FILE="$CAVLI_RECOVERY_DIR/../images/mdm9607-perf-boot-recovery.img"
CHECKSUM_FILE="$CAVLI_RECOVERY_DIR/../images/image_checksums.sha256"
OTA_STATUS_FILE="/data/cavli-ota-status.txt"

# Source the logging utility with multiple fallbacks
source "$CAVLI_RECOVERY_DIR/utils/cavli_log.sh"
# Set custom log tag for this script
set_log_tag "[START-RECOVERY]"

# Source the update_partition script
source "$CAVLI_RECOVERY_DIR/utils/update_partition.sh"

# Reset log for new OTA session
if type reset_ota_log &>/dev/null; then
    reset_ota_log
fi

# Check if files exist
if [ ! -f "$IMAGE_FILE" ]; then
    log_warn "Recovery image not found at $IMAGE_FILE"
    log_at "+OTA: RECOVERY_IMAGE_NOT_FOUND"
    log_warn "Try to boot into recovery mode"
else
    if [ ! -f "$CHECKSUM_FILE" ]; then
        log_warn "Checksum file not found at $CHECKSUM_FILE, continuing without verification"
        CHECKSUM_FILE=""
    fi

    # Update the recovery partition
    log_info "Updating recovery partition..."
    log_info "Using image: $IMAGE_FILE"
    log_at "+OTA: UPDATE_RECOVERY_IMAGE_STARTED"
    update_partition "$MTD_NAME" "$IMAGE_FILE" 131072 "$CHECKSUM_FILE" 0
    UPDATE_RESULT=$?

    if [ $UPDATE_RESULT -ne 0 ]; then
        log_error "Failed to update recovery partition (error code: $UPDATE_RESULT)"
        log_at "+OTA: UPDATE_RECOVERY_IMAGE_FAILED"
        exit 1
    fi

    log_info "Recovery partition updated successfully"
    rm -f "$IMAGE_FILE"
    sync
fi

# Verify the recovery partition contains a valid Android boot image
RECOVERY_DEV=$("$CAVLI_RECOVERY_DIR/utils/mtd.sh" recovery)
if [ $? -eq 0 ] && [ -n "$RECOVERY_DEV" ]; then
    BOOT_MAGIC=$(dd if="$RECOVERY_DEV" bs=1 count=8 2>/dev/null)
    log_debug "Boot magic: $BOOT_MAGIC"
    if [ "$BOOT_MAGIC" = "ANDROID!" ]; then
        log_info "Verified: recovery partition contains a valid Android boot image."
    else
        log_error "Verification failed: recovery partition does not contain a valid Android boot image (missing ANDROID! magic)."
        log_at "+OTA: RECOVERY_IMAGE_MAGIC_INVALID"
        exit 1
    fi
else
    log_error "Could not find recovery partition device for verification."
    exit 1
fi

# Add the auto start recovery script
cp "${CAVLI_RECOVERY_DIR}/cavli_recovery" /etc/init.d/
chmod 755 /etc/init.d/cavli_recovery
ln -sf /etc/init.d/cavli_recovery /etc/rcS.d/S20cavli_recovery 
sync

# Set 755 for all of apps
chmod 755 $CAVLI_RECOVERY_DIR/../apps/*
sync

# Set 755 for all of scripts
chmod 755 $CAVLI_RECOVERY_DIR/*.sh
chmod 755 $CAVLI_RECOVERY_DIR/utils/*.sh
sync

# Remove the OTA status file if it exists
if [ -f "$OTA_STATUS_FILE" ]; then
    rm -f "$OTA_STATUS_FILE"
    sync
    log_info "Removed OTA status file: $OTA_STATUS_FILE"
else
    log_info "No OTA status file to remove"
fi

# Reboot into recovery mode
log_info "Rebooting into recovery mode..."
log_at "+OTA: REBOOT_TO_RECOVERY"
sys_reboot recovery

exit 0
