#!/bin/bash

# === Cavli OTA Logging Base Script ===
# This script provides logging functionality and should be sourced by other scripts
# Usage: source cavli_log.sh

# === Color Support ===
# Define color codes
RESET="\033[0m"
BOLD="\033[1m"
BLACK="\033[30m"
RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
BLUE="\033[34m"
MAGENTA="\033[35m"
CYAN="\033[36m"
WHITE="\033[37m"
BG_RED="\033[41m"

# Color mapping for log levels
COLOR_DEBUG="$CYAN"
COLOR_INFO="$GREEN"
COLOR_WARN="$YELLOW"
COLOR_ERROR="$RED"
COLOR_FATAL="$BOLD$BG_RED"

# Enable/disable colored output (auto-detects if terminal)
CAVLI_COLOR_ENABLED="${CAVLI_COLOR_ENABLED:-1}"

# === Shared Variables ===
# These can be overridden before sourcing or after sourcing
DEFAULT_CAVLI_LOG_TAG="${CAVLI_LOG_TAG:-[]}"
CAVLI_LOG_FILE="${CAVLI_LOG_FILE:-/data/cavli-ota.log}"
CAVLI_LOG_LEVEL="${CAVLI_LOG_LEVEL:-INFO}"  # DEBUG, INFO, WARN, ERROR, FATAL

# Module-specific log tags (associative array)
declare -A MODULE_LOG_TAGS

# Add this function after get_current_log_tag()
debug_log_tag() {
    local caller_id=$(get_caller_id)
    log_info "Current caller: $caller_id"
    log_info "Current tag: ${MODULE_LOG_TAGS[$caller_id]:-$DEFAULT_CAVLI_LOG_TAG}"
    
    # Print all registered tags
    log_info "=== All registered tags ==="
    for key in "${!MODULE_LOG_TAGS[@]}"; do
        log_info "Module: $key, Tag: ${MODULE_LOG_TAGS[$key]}"
    done
}

# Cache for caller IDs to avoid repeated lookups
declare -A CALLER_ID_CACHE

# Fast path for caller ID resolution
get_caller_id() {
    # Create a unique key from current call stack to check cache
    local stack_key="${FUNCNAME[*]}:${BASH_SOURCE[*]}"
    local cached_id="${CALLER_ID_CACHE[$stack_key]}"
    
    # Return cached result if available
    if [[ -n "$cached_id" ]]; then
        echo "$cached_id"
        return 0
    fi
    
    # Otherwise determine caller and cache the result
    local caller_id=$(find_actual_caller)
    CALLER_ID_CACHE[$stack_key]="$caller_id"
    
    echo "$caller_id"
    return 0
}

# The actual caller identification logic
find_actual_caller() {
    local i
    local log_script_path="$(readlink -f "${BASH_SOURCE[0]}")"
    local log_script_dir="$(dirname "$log_script_path")"
    
    # Walk up the call stack efficiently to find the first non-logging script
    for ((i=1; i<${#BASH_SOURCE[@]}; i++)); do
        local frame="${BASH_SOURCE[i]}"
        
        # Skip if empty frame
        [[ -z "$frame" ]] && break
        
        # Use faster string comparison
        if [[ "$frame" != "$log_script_path" && "$frame" != *"/cavli_log.sh" ]]; then
            echo "$(readlink -f "$frame")"
            return 0
        fi
    done
    
    # Fallback if we can't find a non-logging caller
    echo "$(readlink -f "${BASH_SOURCE[1]}")"
    return 0
}

# Fix get_current_log_tag to not output debugging and properly handle tag
get_current_log_tag() {
    local caller_id=$(get_caller_id)
    local tag="${MODULE_LOG_TAGS[$caller_id]:-$DEFAULT_CAVLI_LOG_TAG}"
    
    # Return the tag
    echo "$tag"
}

# Set tag for the current script
set_log_tag() {
    local tag="$1"
    local caller_id=$(get_caller_id)
    MODULE_LOG_TAGS["$caller_id"]="$tag"
}

# Initialize log file if it doesn't exist
init_log() {
    # Create log directory if it doesn't exist
    local log_dir=$(dirname "$CAVLI_LOG_FILE")
    if [ ! -d "$log_dir" ]; then
        mkdir -p "$log_dir" 2>/dev/null || true
    fi
    
    # Create log file if it doesn't exist
    if [ ! -f "$CAVLI_LOG_FILE" ]; then
        touch "$CAVLI_LOG_FILE" 2>/dev/null || true
    fi
    
    # Log script initialization
    cav_log "INFO" "Logging initialized at $(date)"
    
    # Auto-disable colors if not in a terminal
    if [ ! -t 1 ] && [ "$CAVLI_COLOR_ENABLED" == "1" ]; then
        CAVLI_COLOR_ENABLED=0
    fi
}

# Configure UART specification
configure_uart_log() {
    # Configure serial port for logging
    stty -F /dev/ttyMSM0 115200 cs8 -cstopb -parenb
    stty -F /dev/ttyHS4 115200 cs8 -cstopb -parenb
}

# Reset log file for new OTA session
reset_ota_log() {
    local log_dir=$(dirname "$CAVLI_LOG_FILE")
    
    # Create log directory if it doesn't exist
    if [ ! -d "$log_dir" ]; then
        mkdir -p "$log_dir" 2>/dev/null || true
    fi
    
    # Clear log file (truncate to zero)
    : > "$CAVLI_LOG_FILE" 2>/dev/null || true
    
    # Add OTA session header
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo "===== NEW OTA SESSION STARTED AT ${timestamp} =====" >> "$CAVLI_LOG_FILE"
    
    # Log reset event
    cav_log "INFO" "OTA log reset for new update session"
}

# Get color for log level
get_color_for_level() {
    local level="$1"
    
    case "$level" in
        "DEBUG") echo -n "$COLOR_DEBUG" ;;
        "INFO") echo -n "$COLOR_INFO" ;;
        "WARN") echo -n "$COLOR_WARN" ;;
        "ERROR") echo -n "$COLOR_ERROR" ;;
        "FATAL") echo -n "$COLOR_FATAL" ;;
        *) echo -n "$RESET" ;;
    esac
}

# Core logging functions
cav_log() {
    local level="$1"
    local message="$2"
    local log_tag=$(get_current_log_tag)
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    local log_entry="${timestamp} ${log_tag} ${level}: ${message}"
    local colored_entry=""
    local log_enabled=0
    
    # Add colors if enabled
    if [ "$CAVLI_COLOR_ENABLED" == "1" ]; then
        local level_color=$(get_color_for_level "$level")
        colored_entry="${timestamp} ${BLUE}[CAVLI]${log_tag}${RESET} ${level_color}${level}${RESET}: ${message}"
    else
        colored_entry="$log_entry"
    fi
    
    # Check if we should log based on log level
    case "$CAVLI_LOG_LEVEL" in
        "DEBUG") log_enabled=1 ;;
        "INFO") [[ "$level" != "DEBUG" ]] && log_enabled=1 ;;
        "WARN") [[ "$level" != "DEBUG" && "$level" != "INFO" ]] && log_enabled=1 ;;
        "ERROR") [[ "$level" == "ERROR" || "$level" == "FATAL" ]] && log_enabled=1 ;;
        "FATAL") [[ "$level" == "FATAL" ]] && log_enabled=1 ;;
        *) log_enabled=1 ;;
    esac
    
    if [[ $log_enabled -eq 1 ]]; then
        # Log to serial port if available (no colors)
        if [ -e "/dev/ttyMSM0" ]; then
            echo "${log_entry}" > /dev/ttyMSM0
        fi
        
        # Log to system log (no colors)
        echo "${log_entry}" | tee /dev/kmsg >/dev/null 2>&1 || true
        
        # Log to stdout/stderr (with colors)
        if [[ "$level" == "ERROR" || "$level" == "FATAL" ]]; then
            echo -e "${colored_entry}" >&2
        else
            echo -e "${colored_entry}"
        fi
        
        # Append to log file (no colors)
        echo "${log_entry}" >> "$CAVLI_LOG_FILE" 2>/dev/null || true
    fi
}

# === Log Level Functions ===
log_debug() {
    cav_log "DEBUG" "$1"
}

log_info() {
    cav_log "INFO" "$1"
}

log_warn() {
    cav_log "WARN" "$1"
}

log_error() {
    cav_log "ERROR" "$1"
}

log_fatal() {
    cav_log "FATAL" "$1"
    exit 1
}

# Log to AT port (ttyHS4)
log_at() {
    echo -e "$1\r\n" > /dev/ttyHS4
}

# Enable or disable colors
toggle_colors() {
    if [ "$1" == "on" ] || [ "$1" == "1" ]; then
        CAVLI_COLOR_ENABLED=1
        log_info "Color output enabled"
    elif [ "$1" == "off" ] || [ "$1" == "0" ]; then
        CAVLI_COLOR_ENABLED=0
        log_info "Color output disabled"
    else
        log_warn "Invalid parameter for toggle_colors: use 'on'/'off' or '1'/'0'"
    fi
}

# Initialize logging if this script is being executed directly
# If sourced, the sourcing script should call init_log
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    init_log
    log_info "Script executed directly rather than sourced"
fi
