#!/bin/bash

# Get the directory where this script is located, even when sourced
SCRIPT_DIR="$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")"

# Source the logging utility
# source "$SCRIPT_DIR/cavli_log.sh"
# Set custom log tag for this script
# set_log_tag "[MTD]"

# Find MTD device by name and return the corresponding /dev/mtdblockX path
# Usage: find_mtd_device [partition_name]
find_mtd_device() {
    local MTD_NAME="${1}"
    local MTD_LINE
    local MTD_INDEX
    
    # Check if /proc/mtd exists
    if [ ! -f "/proc/mtd" ]; then
        # log_error "MTD subsystem not available (/proc/mtd not found)"
        return 1
    fi
    
    # log_debug "Looking for MTD partition named \"$MTD_NAME\""
    MTD_LINE=$(grep "\"$MTD_NAME\"" /proc/mtd)

    if [ -z "$MTD_LINE" ]; then
        # log_error "No '$MTD_NAME' MTD partition found in /proc/mtd"
        return 1
    fi

    MTD_INDEX=$(echo "$MTD_LINE" | cut -d: -f1 | sed 's/mtd//')

    if [ -z "$MTD_INDEX" ]; then
        # log_error "Failed to extract index from MTD entry"
        return 1
    fi
    
    # Check if the MTD block device exists
    if [ ! -e "/dev/mtdblock$MTD_INDEX" ]; then
        # log_error "MTD block device /dev/mtdblock$MTD_INDEX does not exist"
        return 1
    fi

    # log_debug "Found $MTD_NAME at /dev/mtdblock$MTD_INDEX"
    echo "/dev/mtdblock$MTD_INDEX"
    return 0
}


# Get MTD information for a named partition
# Usage: get_mtd_info [partition_name]
get_mtd_info() {
    local MTD_NAME="${1}"
    local MTD_LINE
    
    # Check if /proc/mtd exists
    if [ ! -f "/proc/mtd" ]; then
        # log_error "MTD subsystem not available (/proc/mtd not found)"
        return 1
    fi
    
    # log_debug "Getting info for MTD partition named \"$MTD_NAME\""
    MTD_LINE=$(grep "\"$MTD_NAME\"" /proc/mtd)

    if [ -z "$MTD_LINE" ]; then
        # log_error "No '$MTD_NAME' MTD partition found in /proc/mtd"
        return 1
    fi

    # Parse the size and other details from the MTD line
    local MTD_DEV=$(echo "$MTD_LINE" | cut -d: -f1)
    local MTD_SIZE=$(echo "$MTD_LINE" | awk '{print $2}')
    local MTD_ERASESIZE=$(echo "$MTD_LINE" | awk '{print $3}')
    
    # Convert hex to decimal for sizes
    MTD_SIZE=$((16#${MTD_SIZE}))
    MTD_ERASESIZE=$((16#${MTD_ERASESIZE}))
    
    # Print information as JSON for easy parsing
    echo "{\"device\":\"$MTD_DEV\",\"name\":\"$MTD_NAME\",\"size\":$MTD_SIZE,\"erasesize\":$MTD_ERASESIZE}"
    return 0
}

# List all available MTD partitions
list_mtd_partitions() {
    if [ ! -f "/proc/mtd" ]; then
        # log_error "MTD subsystem not available (/proc/mtd not found)"
        return 1
    fi

    # log_info "Available MTD partitions:"
    echo "--------------------------------"
    echo "Device    Size      Name"
    echo "--------------------------------"
    
    # Skip the header line and parse each MTD partition
    sed '1d' /proc/mtd | while read line; do
        local dev=$(echo "$line" | cut -d: -f1)
        local size=$(echo "$line" | awk '{print $2}')
        # Extract name between quotes
        local name=$(echo "$line" | grep -o '".*"' | sed 's/"//g')
        # Convert hex size to human-readable format
        local size_dec=$((16#${size}))
        local size_human
        if [ $size_dec -ge 1048576 ]; then
            size_human="$((size_dec / 1048576)) MB"
        else
            size_human="$((size_dec / 1024)) KB"
        fi
        printf "%-9s %-9s %s\n" "/dev/$dev" "$size_human" "$name"
    done
    echo "--------------------------------"
    return 0
}

# If script is called directly, show usage example
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    if [ "$1" == "list" ]; then
        list_mtd_partitions
    elif [ -n "$1" ]; then
        DEVICE=$(find_mtd_device "$1")
        RET=$?
        # if [ $RET -eq 0 ]; then
        #     log_info "Found partition '$1' at $DEVICE"
        # fi
        echo "$DEVICE"
        exit $RET
    else
        echo "Usage: $(basename "$0") [partition_name|list]"
        echo ""
        echo "Examples:"
        echo "  $(basename "$0") recovery     # Find mtdblock device for 'recovery' partition"
        echo "  $(basename "$0") list         # List all available MTD partitions"
        exit 1
    fi
fi
