#!/bin/bash

# Get the directory where this script is located
SCRIPT_DIR="$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")"

# Source the logging script
source "$SCRIPT_DIR/cavli_log.sh"

# Set custom log tag for this script
set_log_tag "[CAVLI-MONITOR]"

# Path to store the monitor PID
MONITOR_PID_FILE="/var/run/at_daemon_monitor.pid"

# Flag file to indicate monitoring should continue
MONITOR_FLAG_FILE="/var/run/at_daemon_monitor.flag"

# List of processes to monitor and kill
MONITORED_PROCESSES=(
    "atcminitd"
    "atcmd"
    "mem-monitor"
    "mem-monitor.sh"
)

# Function to kill monitored processes
kill_cavli_daemons() {
    # log_info "Checking for AT daemon processes..."
    local killed_count=0
    
    for process in "${MONITORED_PROCESSES[@]}"; do
        # Check if the process exists
        if pgrep -f "$process" >/dev/null; then
            log_info "Found process matching '$process', killing it"
            
            # First try force kill
            pkill -9 -f "$process"

            if [ "$process" == "atcmd" ]; then
                # Kill startup process of atcmd
                pkill -9 -f atcminitd
            elif [ "$process" == "mem-monitor.sh" ]; then
                # Kill startup process of mem-monitor
                pkill -9 -f mem-monitor
            fi
            
            killed_count=$((killed_count + 1))
        fi
    done
    
    if [ $killed_count -gt 0 ]; then
        log_info "Killed $killed_count processes"
    else
        log_debug "No daemon processes found"
    fi
    
    return $killed_count
}

# Function to start the monitor
start_monitor() {
    log_info "Starting AT daemon monitor service"
    
    # Check if already running
    if [ -f "$MONITOR_PID_FILE" ]; then
        local pid=$(cat "$MONITOR_PID_FILE" 2>/dev/null)
        if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
            log_info "Monitor already running with PID $pid"
            return 0
        else
            log_info "Removing stale PID file"
            rm -f "$MONITOR_PID_FILE"
        fi
    fi
    
    # Create flag file to indicate monitoring should continue
    mkdir -p "$(dirname "$MONITOR_FLAG_FILE")" 2>/dev/null
    touch "$MONITOR_FLAG_FILE"
    
    # Start the monitor in background
    {
        # Initial kill of any existing processes
        kill_cavli_daemons
        
        # Set up trap to clean up on exit
        trap 'rm -f "$MONITOR_FLAG_FILE"; rm -f "$MONITOR_PID_FILE"; log_info "Monitor stopped"; exit 0' EXIT
        
        # Save PID to file
        echo $$ > "$MONITOR_PID_FILE"
        
        log_info "Monitor service started with PID $$"
        
        # Main monitoring loop
        while [ -f "$MONITOR_FLAG_FILE" ]; do
            # Check and kill AT daemons
            kill_cavli_daemons >/dev/null
            
            # Sleep before next check (adjust interval as needed)
            sleep 0.5
        done
    } &
    
    # Give the background process time to initialize
    sleep 1
    
    # Verify monitor is running
    if [ -f "$MONITOR_PID_FILE" ]; then
        local pid=$(cat "$MONITOR_PID_FILE" 2>/dev/null)
        if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
            log_info "Monitor successfully started with PID $pid"
            return 0
        fi
    fi
    
    log_error "Failed to start monitor service"
    return 1
}

# Function to stop the monitor
stop_monitor() {
    log_info "Stopping AT daemon monitor service"
    
    # Remove flag file to signal monitor to stop
    rm -f "$MONITOR_FLAG_FILE"
    
    # Check if PID file exists
    if [ -f "$MONITOR_PID_FILE" ]; then
        local pid=$(cat "$MONITOR_PID_FILE" 2>/dev/null)
        if [ -n "$pid" ]; then
            # Send signal to terminate
            kill -TERM "$pid" 2>/dev/null
            
            # Wait for process to terminate
            local timeout=5
            while [ $timeout -gt 0 ] && kill -0 "$pid" 2>/dev/null; do
                sleep 1
                timeout=$((timeout - 1))
            done
            
            # Force kill if still running
            if kill -0 "$pid" 2>/dev/null; then
                log_warn "Monitor didn't terminate gracefully, forcing kill"
                kill -9 "$pid" 2>/dev/null
            fi
        fi
        
        # Remove PID file
        rm -f "$MONITOR_PID_FILE"
    fi
    
    log_info "Monitor service stopped"
    return 0
}

# Function to check status of the monitor
status_monitor() {
    if [ -f "$MONITOR_PID_FILE" ]; then
        local pid=$(cat "$MONITOR_PID_FILE" 2>/dev/null)
        if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
            log_info "Monitor is running with PID $pid"
            return 0
        else
            log_info "Monitor is not running (stale PID file)"
            return 1
        fi
    else
        log_info "Monitor is not running"
        return 1
    fi
}

# Command line argument handling
case "$1" in
    start)
        start_monitor
        ;;
    stop)
        stop_monitor
        ;;
    restart)
        stop_monitor
        start_monitor
        ;;
    status)
        status_monitor
        ;;
    kill-now)
        # Just kill processes once without starting monitor
        kill_cavli_daemons
        ;;
    *)
        echo "Usage: $0 {start|stop|restart|status|kill-now}"
        exit 1
        ;;
esac

exit $?