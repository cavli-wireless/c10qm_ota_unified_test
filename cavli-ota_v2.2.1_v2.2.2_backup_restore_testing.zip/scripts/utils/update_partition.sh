#!/bin/bash

# Get the directory where this script is located, even when sourced
SCRIPT_DIR="$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")"

# Source the logging utility
source "$SCRIPT_DIR/cavli_log.sh"
# Set custom log tag for this script
set_log_tag "[UPDATE-PARTITION]"

# Source the MTD and checksum utilities
if [ -f "$SCRIPT_DIR/mtd.sh" ]; then
    source "$SCRIPT_DIR/mtd.sh"
else
    log_error "Required utility mtd.sh not found in $SCRIPT_DIR"
    exit 1
fi

if [ -f "$SCRIPT_DIR/checksum.sh" ]; then
    source "$SCRIPT_DIR/checksum.sh"
else
    log_error "Required utility checksum.sh not found in $SCRIPT_DIR"
    exit 1
fi

# Function to update any partition
update_partition() {
    local partition_name="$1"       # First argument
    local image_file="$2"           # Second argument
    local block_size="${3:-4096}"   # Default block size
    local checksum_file="$4"
    local force_write="${5:-0}"
    
    # Validate image file exists
    if [ ! -f "$image_file" ]; then
        log_error "$partition_name image not found: $image_file"
        return 1
    fi
    
    # Verify checksum if checksum file is provided
    if [ -n "$checksum_file" ] && [ "$force_write" != "1" ]; then
        log_info "Verifying checksum for $partition_name image..."
        if ! verify_checksum "$image_file" "$checksum_file"; then
            log_error "Checksum verification failed. Aborting update."
            return 1
        fi
        log_info "Checksum verification passed!"
    elif [ "$force_write" != "1" ]; then
        log_warn "No checksum file provided. Skipping verification."
    fi
    
    # Find MTD partition
    log_info "Finding $partition_name MTD partition..."
    local mtd_device=$(find_mtd_device "$partition_name")
    if [ $? -ne 0 ] || [ -z "$mtd_device" ]; then
        log_error "Failed to find $partition_name MTD partition"
        return 1
    fi
    log_info "Found $partition_name partition at $mtd_device"
    
    # Get file size
    local image_size=$(stat -c "%s" "$image_file")
    if [ $? -ne 0 ] || [ -z "$image_size" ]; then
        log_error "Failed to determine image size"
        return 1
    fi
    log_info "$partition_name image size: $image_size bytes"
    
    # Get partition size to ensure it fits
    local mtd_info=$(get_mtd_info "$partition_name")
    if [ $? -ne 0 ] || [ -z "$mtd_info" ]; then
        log_error "Failed to get $partition_name partition info"
        return 1
    fi
    
    # Parse partition size from mtd_info JSON
    local partition_size=$(echo "$mtd_info" | grep -o '"size":[0-9]*' | cut -d ':' -f 2)
    if [ -z "$partition_size" ]; then
        log_warn "Could not determine partition size, continuing anyway"
    else
        if [ "$image_size" -gt "$partition_size" ]; then
            log_error "$partition_name image ($image_size bytes) is too large for partition ($partition_size bytes)"
            return 1
        fi
        log_info "Partition size: $partition_size bytes (sufficient space available)"
    fi
    
    # Write image to partition
    log_info "Writing $partition_name image to $mtd_device..."
    log_info "This may take a while, please do not power off the device!"
    
    if ! dd if="$image_file" of="$mtd_device" bs=$block_size conv=fsync; then
        log_error "Failed to write $partition_name image to $mtd_device"
        return 1
    fi
    
    log_info "$partition_name partition update completed successfully!"
    return 0
}

# Only execute this section if the script is run directly (not sourced)
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    # Define default values
    PARTITION_NAME=""
    IMAGE_PATH=""
    BLOCK_SIZE="4096"
    CHECKSUM_FILE=""
    FORCE_WRITE=0
    
    # Print usage
    print_usage() {
        echo "Usage: $(basename "$0") [OPTIONS]"
        echo ""
        echo "Options:"
        echo "  -n, --name PARTITION   Name of partition to update (required)"
        echo "  -p, --path IMAGE_PATH  Path to the partition image (required)"
        echo "  -b, --block SIZE       Block size for writing (default: 4096)"
        echo "  -c, --checksum FILE    Path to checksum file for verification"
        echo "  -f, --force            Skip checksum verification"
        echo "  -h, --help             Display this help message"
        echo ""
        echo "Examples:"
        echo "  $(basename "$0") -n recovery -p /path/to/recovery.img -b 131072 -c /path/to/checksums.txt"
        echo "  $(basename "$0") --name boot --path /path/to/boot.img --block 131072"
        echo "  $(basename "$0") -n system -p /path/to/system.img -f"
    }
    
    # Check if no arguments or help requested
    if [[ $# -eq 0 || "$1" == "-h" || "$1" == "--help" ]]; then
        print_usage
        exit 0
    fi
    
    # Modern argument parsing
    log_info "Parsing command line arguments"
    while [[ $# -gt 0 ]]; do
        case "$1" in
            -n|--name)
                if [[ -z "$2" || "$2" == -* ]]; then
                    log_error "Missing argument for $1 option"
                    print_usage
                    exit 1
                fi
                PARTITION_NAME="$2"
                shift 2
                ;;
            -p|--path)
                if [[ -z "$2" || "$2" == -* ]]; then
                    log_error "Missing argument for $1 option"
                    print_usage
                    exit 1
                fi
                IMAGE_PATH="$2"
                shift 2
                ;;
            -b|--block)
                if [[ -z "$2" || "$2" == -* ]]; then
                    log_error "Missing argument for $1 option"
                    print_usage
                    exit 1
                fi
                BLOCK_SIZE="$2"
                shift 2
                ;;
            -c|--checksum)
                if [[ -z "$2" || "$2" == -* ]]; then
                    log_error "Missing argument for $1 option"
                    print_usage
                    exit 1
                fi
                CHECKSUM_FILE="$2"
                shift 2
                ;;
            -f|--force)
                FORCE_WRITE=1
                shift
                ;;
            -h|--help)
                print_usage
                exit 0
                ;;
            *)
                log_error "Unknown option: $1"
                print_usage
                exit 1
                ;;
        esac
    done
    
    # Validate required parameters
    if [[ -z "$PARTITION_NAME" || -z "$IMAGE_PATH" ]]; then
        log_error "Partition name and image path are required"
        print_usage
        exit 1
    fi
    
    # Log the parsed arguments for debugging
    log_info "Running with parameters:"
    log_info "  Partition: $PARTITION_NAME"
    log_info "  Image: $IMAGE_PATH" 
    log_info "  Block Size: $BLOCK_SIZE"
    log_info "  Checksum File: ${CHECKSUM_FILE:-None}"
    log_info "  Force Write: $FORCE_WRITE"
    
    # Call the update_partition function with parsed arguments
    update_partition "$PARTITION_NAME" "$IMAGE_PATH" "$BLOCK_SIZE" "$CHECKSUM_FILE" "$FORCE_WRITE"
    exit $?
fi

# Export functions when sourced
if [[ "${BASH_SOURCE[0]}" != "${0}" ]]; then
    export -f update_partition
    log_debug "update_partition.sh sourced - functions exported"
fi
