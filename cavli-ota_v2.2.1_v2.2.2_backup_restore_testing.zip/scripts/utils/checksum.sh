#!/bin/bash

# Get the directory where this script is located, even when sourced
SCRIPT_DIR="$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")"

# Source the logging utility
source "$SCRIPT_DIR/cavli_log.sh"
# Set custom log tag for this script
set_log_tag "[CHECKSUM]"

# Verify image checksum using SHA256
# Usage: verify_checksum <file_path> <checksum_file_path>
# Returns: 0 if checksum matches, 1 if not
verify_checksum() {
    local img_file="$1"
    local checksum_file="$2"
    local img_basename=$(basename "$img_file")
    local expected_checksum=""
    local actual_checksum=""
    
    # Validate inputs
    if [ ! -f "$img_file" ]; then
        log_error "Input file not found: $img_file"
        return 1
    fi
    
    # Check if checksums file exists
    if [ ! -f "$checksum_file" ]; then
        log_error "Checksums file not found: $checksum_file"
        return 1
    fi
    
    # Extract expected checksum for this specific image from the checksums file
    expected_checksum=$(grep "$img_basename" "$checksum_file" | awk '{print $1}')
    if [ -z "$expected_checksum" ]; then
        # Try alternative approach - some checksum files might be formatted differently
        expected_checksum=$(grep -A1 "$img_basename" "$checksum_file" | tail -n1 | awk '{print $1}')
        
        if [ -z "$expected_checksum" ]; then
            log_error "Failed to find checksum for $img_basename in $checksum_file"
            return 1
        fi
    fi
    
    # Calculate actual SHA256 checksum
    log_info "Calculating SHA256 checksum for $img_file..."
    actual_checksum=$(sha256sum "$img_file" | awk '{print $1}')
    if [ -z "$actual_checksum" ]; then
        log_error "Failed to calculate SHA256 checksum for $img_file"
        return 1
    fi
    
    # Compare checksums
    if [ "$expected_checksum" != "$actual_checksum" ]; then
        log_error "Checksum verification failed for $img_basename!"
        log_error "Expected: $expected_checksum"
        log_error "Actual:   $actual_checksum"
        return 1
    fi
    
    log_info "SHA256 checksum verification successful for $img_basename"
    return 0
}

# Direct execution entry point
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    # Display usage if no arguments provided
    if [ $# -lt 2 ]; then
        echo "Usage: $(basename "$0") <file> <checksums_file>"
        echo ""
        echo "Examples:"
        echo "  $(basename "$0") image.bin checksums.txt"
        exit 1
    fi
    
    # Call verify_checksum with provided arguments
    verify_checksum "$1" "$2"
    exit $?
fi