#!/bin/bash
# cfdps.sh
# Robust file save/restore utility for embedded systems with limited storage
# Supports auto-allocation and recovery of large files across /data, /rootfs, /firmware

# Use log_debug from cavli_log.sh for all echo calls
SCRIPT_DIR="$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")"
CAVLI_LOG="$SCRIPT_DIR/../utils/cavli_log.sh"
if [ -f "$CAVLI_LOG" ]; then
    source "$CAVLI_LOG"
    # Set custom log tag for this script
    set_log_tag "[CAVLI-FDPS]"
fi

# Mock echo to use log_info if available
log() {
    if declare -F log_info >/dev/null 2>&1; then
        log_info "$@"
    else
        echo "$@"
    fi
}

# Margin in KB to keep free in each partition
MARGIN_KB=500
ALL_PARTITIONS=("/data" "/firmware" "/")
MAGIC_DIR="cavli-fdps"
INFO_DIR="/data/$MAGIC_DIR/info"
PARTS_SUBDIR="$MAGIC_DIR/parts"

# Function: get_free_kb <mountpoint>
get_free_kb() {
    df -k "$1" | awk 'NR==2 {print $4}'
}

# Function: get_rw_partitions
get_rw_partitions() {
    local rw_parts=()
    for part in "${ALL_PARTITIONS[@]}"; do
        if mountpoint -q "$part" && grep " $part " /proc/mounts | grep -q ' rw,'; then
            rw_parts+=("$part")
        fi
    done
    echo "${rw_parts[@]}"
}

cfdps_init() {
    log "Initializing auto file allocator..."
    # Remount all partitions in ALL_PARTITIONS as read-write if not already rw
    for part in "${ALL_PARTITIONS[@]}"; do
        if mountpoint -q "$part"; then
            if grep " $part " /proc/mounts | grep -q ' rw,'; then
                log "$part is already mounted read-write."
            else
                log "Remounting $part as read-write..."
                mount -o remount,rw "$part"
                sleep 0.5  # Give the mount operation time to complete
                # Check again if partition is now read-write
                if grep " $part " /proc/mounts | grep -q ' rw,'; then
                    log "$part is now mounted read-write."
                else
                    log "[WARN] $part is still not mounted read-write after remount!"
                fi
            fi
        else
            log "$part is not mounted."
        fi
    done
    # Init info directory
    mkdir -p "$INFO_DIR"
}

cfdps_deinit() {
    log "Deinitializing auto file allocator..."
    # Remove all fdps directories in each partition
    local PARTITIONS=($(get_rw_partitions))
    for fdps_dir in "${PARTITIONS[@]}"; do
        fdps_path="$fdps_dir/$MAGIC_DIR"
        if [ -d "$fdps_path" ]; then
            log_info "Removing $fdps_path"
            rm -rf "$fdps_path"
        fi
    done
    # Many process of OTA need to read/write into / and /firmware
    # atcmd still need to chmod again after firmware updated
    # Disable it first
    # # Remount / read-only
    # mount -o remount,ro /
    # Remount /firmware read-only
    # mount -o remount,ro /firmware
}

# Function: cfdps_save_file <input_file> <tag>
cfdps_save_file() {
    local input_file="$1"
    local tag="$2"
    local base_name=$(basename "$input_file")
    local info_file="$INFO_DIR/${tag}.info"
    local total_size=$(stat -c %s "$input_file")
    local saved=0
    local part_idx=1
    local offset=0
    local part_paths=()

    # Get read-write partitions
    local PARTITIONS=($(get_rw_partitions))

    # Try to save whole file in one partition
    for part_dir in "${PARTITIONS[@]}"; do
        free_kb=$(get_free_kb "$part_dir")
        usable_kb=$((free_kb - MARGIN_KB))
        [ $usable_kb -le 0 ] && continue
        usable_bytes=$((usable_kb * 1024))
        if [ $usable_bytes -ge $total_size ]; then
            out_path="$part_dir/$PARTS_SUBDIR/${tag}"
            mkdir -p "$(dirname "$out_path")"
            echo "single=1" > "$info_file"
            echo "path1=$out_path" >> "$info_file"
            echo "size1=$total_size" >> "$info_file"
            echo "original_name=$base_name" >> "$info_file"
            echo "original_size=$total_size" >> "$info_file"
            echo "part_count=1" >> "$info_file"
            echo "tag=$tag" >> "$info_file"
            cp "$input_file" "$out_path"
            echo "save_complete=1" >> "$info_file"
            sync
            log "Saved $input_file as a single file in $out_path"
            return 0
        fi
    done

    # Need to split into parts using greedy-fit block allocation
    BLOCK_SIZE=1048576  # 1MB
    declare -a part_sizes
    declare -a part_dirs
    total_avail=0
    # 1. Calculate available space in each partition (rounded down to BLOCK_SIZE)
    for part_dir in "${PARTITIONS[@]}"; do
        free_kb=$(get_free_kb "$part_dir")
        usable_kb=$((free_kb - MARGIN_KB))
        [ $usable_kb -le 0 ] && part_sizes+=(0) && part_dirs+=("$part_dir") && continue
        usable_bytes=$((usable_kb * 1024))
        fit_bytes=$((usable_bytes / BLOCK_SIZE * BLOCK_SIZE))
        part_sizes+=("$fit_bytes")
        part_dirs+=("$part_dir")
        total_avail=$((total_avail + fit_bytes))
    done

    # 2. Check if total available space is enough
    if [ $total_avail -lt $total_size ]; then
        log "ERROR: Not enough space in all partitions to save file!" >&2
        return 1
    fi

    # 3. Write parts
    echo "single=0" > "$info_file"
    echo "original_name=$base_name" >> "$info_file"
    echo "original_size=$total_size" >> "$info_file"
    echo "tag=$tag" >> "$info_file"
    echo "part_count=0" >> "$info_file"
    part_count=0
    offset=0
    part_idx=1
    remaining=$total_size
    for i in "${!part_dirs[@]}"; do
        this_size=${part_sizes[$i]}
        [ $this_size -le 0 ] && continue
        [ $remaining -le 0 ] && break
        # For last part, use remaining size
        [ $this_size -gt $remaining ] && this_size=$remaining
        out_path="${part_dirs[$i]}/$PARTS_SUBDIR/${tag}.part${part_idx}"
        mkdir -p "$(dirname "$out_path")"
        # Should be updated before writing to out path
        part_count=$((part_count+1))
        # log "part_count=$part_count" >> "$info_file"
        # we should update the part_count in the info file
        # find part_count and update it
        sed -i "s/^part_count=.*/part_count=$part_count/" "$info_file"
        echo "path${part_count}=$out_path" >> "$info_file"
        echo "size${part_count}=$this_size" >> "$info_file"
        # if [ $((this_size % BLOCK_SIZE)) -eq 0 ]; then
        #     # Full block, use bs=1M
        #     dd if="$input_file" of="$out_path" bs=1M count=$((this_size / BLOCK_SIZE)) skip=$((offset / BLOCK_SIZE))
        # else
        #     # Remainder, use bs=1
        #     log "this_size=$this_size"
        #     dd if="$input_file" of="$out_path" bs=1 count=$this_size skip=$offset
        # fi
        if [ $((this_size / BLOCK_SIZE)) -gt 0 ]; then
            # Full block, use tail+head for speed and safety
            tail -c +$((offset+1)) "$input_file" | head -c $this_size > "$out_path"
        else
            # Remainder, use tail+head
            tail -c +$((offset+1)) "$input_file" | head -c $this_size > "$out_path"
        fi
        sync
        if [ $? -eq 0 ]; then
            offset=$((offset + this_size))
            remaining=$((remaining - this_size))
        fi
        part_idx=$((part_idx+1))
    done
    echo "save_complete=1" >> "$info_file"
    sync
    log "Saved $input_file in $part_count parts. Info: $info_file"
    return 0
}

# Function: cfdps_restore_file <tag> <output_file>
cfdps_restore_file() {
    local tag="$1"
    local output_file="$2"
    local info_file="$INFO_DIR/${tag}.info"
    [ -f "$info_file" ] || { log "No info file for tag $tag" >&2; return 1; }
    . "$info_file"
    if [ "$save_complete" != "1" ]; then
        log "ERROR: File save not complete for tag $tag. Restore not allowed." >&2
        return 1
    fi
    rm -f "$output_file"
    if [ "$single" = "1" ]; then
        cp "$path1" "$output_file"
        log "Restored $output_file from $path1"
        return 0
    fi
    for i in $(seq 1 $part_count); do
        part_var="path$i"
        cat "${!part_var}" >> "$output_file"
    done
    log "Restored $output_file from $part_count parts."
    return 0
}

# Function: cfdps_check_file_saved <tag>
cfdps_check_file_saved() {
    local tag="$1"
    local info_file="$INFO_DIR/${tag}.info"
    [ -f "$info_file" ] || { log "NOT_FOUND"; return 1; }
    . "$info_file"
    if [ "$save_complete" = "1" ]; then
        log "SAVED"
        return 0
    else
        log "NOT_SAVED"
        return 2
    fi
}

# Function: cfdps_clear_file_parts <tag>
cfdps_clear_file_parts() {
    local tag="$1"
    local info_file="$INFO_DIR/${tag}.info"
    [ -f "$info_file" ] || { log "No info file for tag $tag" >&2; return 1; }
    . "$info_file"
    for i in $(seq 1 $part_count); do
        part_var="path$i"
        log "Removing ${!part_var}"
        rm -f "${!part_var}"
    done
    rm -f "$info_file"
    sync
    log "Cleared file parts for tag $tag"
}

# Function: cfdps_delete_all_file_parts
cfdps_delete_all_file_parts() {
    for info_file in "$INFO_DIR"/*.info; do
        [ -f "$info_file" ] || continue
        tag=$(basename "$info_file" .info)
        log "Checking file: $info_file"
        cfdps_check_file_saved "$tag"
        log "Deleting file: $info_file"
        cfdps_clear_file_parts "$tag"
    done
}

# Function: cfdps_list_tags_with_prefix <tag_prefix>
cfdps_list_tags_with_prefix() {
    local prefix="$1"
    local info_file
    local tag
    for info_file in "$INFO_DIR"/*.info; do
        [ -f "$info_file" ] || continue
        tag=$(basename "$info_file" .info)
        case "$tag" in
            "$prefix"*) log "$tag" ;;
        esac
    done
}

# Function: cfdps_restore_all_with_prefix <tag_prefix> <output_dir>
cfdps_restore_all_with_prefix() {
    local prefix="$1"
    local outdir="$2"
    local info_file tag original_name
    mkdir -p "$outdir"
    for info_file in "$INFO_DIR"/*.info; do
        [ -f "$info_file" ] || continue
        tag=$(basename "$info_file" .info)
        case "$tag" in
            "$prefix"*)
                # shellcheck source=/dev/null
                . "$info_file"
                if [ -n "$original_name" ]; then
                    cfdps_restore_file "$tag" "$outdir/$original_name"
                else
                    log "[WARN] No original_name in $info_file, skipping."
                fi
                ;;
        esac
    done
}

# Usage examples:
# cfdps_save_file /path/to/largefile.bin mytag
# cfdps_restore_file mytag /path/to/restore.bin
# cfdps_check_file_saved mytag
# cfdps_clear_file_parts mytag
# cfdps_delete_all_file_parts