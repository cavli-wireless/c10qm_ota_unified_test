#!/bin/bash

sysctl -w kernel.core_pattern='|/bin/false'
