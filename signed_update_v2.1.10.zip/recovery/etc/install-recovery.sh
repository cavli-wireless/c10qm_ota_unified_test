#!/system/bin/sh
if ! applypatch -c MTD:recovery:6301696:decfbf958d54e8b2dc00c2c6691e068fc2dfcb3b; then
  applypatch  MTD:boot:6301696:decfbf958d54e8b2dc00c2c6691e068fc2dfcb3b MTD:recovery decfbf958d54e8b2dc00c2c6691e068fc2dfcb3b 6301696 decfbf958d54e8b2dc00c2c6691e068fc2dfcb3b:/system/recovery-from-boot.p && log -t recovery "Installing new recovery image: succeeded" || log -t recovery "Installing new recovery image: failed"
else
  log -t recovery "Recovery image already installed"
fi
